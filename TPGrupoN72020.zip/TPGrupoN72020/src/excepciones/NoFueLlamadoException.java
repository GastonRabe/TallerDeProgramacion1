package excepciones;

public class NoFueLlamadoException extends Exception {

}
