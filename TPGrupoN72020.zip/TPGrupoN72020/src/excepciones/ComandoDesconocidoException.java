package excepciones;

public class ComandoDesconocidoException extends Exception {

}
