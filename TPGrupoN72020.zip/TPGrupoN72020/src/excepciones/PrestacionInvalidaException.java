package excepciones;

public class PrestacionInvalidaException extends Exception {

}
