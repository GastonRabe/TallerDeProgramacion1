package excepciones;

public class MedicoNuloException extends Exception {

}
