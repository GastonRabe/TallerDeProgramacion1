package excepciones;

public class MatriculaInvalidaException extends Exception {

}
