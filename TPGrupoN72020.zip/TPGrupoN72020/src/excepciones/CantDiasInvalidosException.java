package excepciones;

public class CantDiasInvalidosException extends Exception {

}
