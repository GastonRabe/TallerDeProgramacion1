package excepciones;

public class PacienteRepetidoException extends Exception {

}
