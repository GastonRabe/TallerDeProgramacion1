package excepciones;

public class MedicoRepetidoException extends Exception {

}
