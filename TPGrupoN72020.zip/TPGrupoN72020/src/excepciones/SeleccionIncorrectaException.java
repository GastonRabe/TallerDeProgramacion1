package excepciones;

public class SeleccionIncorrectaException extends Exception {

}
