package excepciones;

public class FechaInvalidaException extends Exception {

}
