package excepciones;

public class PacienteYaIngresadoException extends Exception {

}
