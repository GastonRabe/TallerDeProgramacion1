package excepciones;

public class ReporteInvalidoException extends Exception {

}
