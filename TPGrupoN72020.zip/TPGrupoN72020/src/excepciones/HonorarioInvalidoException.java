package excepciones;

public class HonorarioInvalidoException extends Exception {

}
