package excepciones;

public class NoSeleccionoException extends Exception
{

}
