package excepciones;

public class JugoRobinhoException extends Exception {

}
