package excepciones;

public class NoHayEspacioException extends Exception {

}
