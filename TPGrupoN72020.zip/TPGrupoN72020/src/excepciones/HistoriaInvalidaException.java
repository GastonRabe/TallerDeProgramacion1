package excepciones;

public class HistoriaInvalidaException extends Exception {

}
