package excepciones;

public class NoHayPacienteEsperandoException extends Exception{

}
