package vista;

import java.awt.Component;

public interface InterfazOptionPanel {

	 void ShowMessage(Component parent, String mensaje);
	 
}
