package habitaciones;

public class HabCompartidaComun extends HabCompartida
{

	public HabCompartidaComun(double costoAsignacion) {
		super(costoAsignacion);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "HabCompartidaComun " + super.toString();
	}
	
	

}
