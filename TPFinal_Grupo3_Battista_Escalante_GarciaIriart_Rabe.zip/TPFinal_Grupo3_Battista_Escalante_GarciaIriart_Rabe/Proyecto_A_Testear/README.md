# Trabajo Práctico Grupal - Programación III
#### *Sistema de Gestion de Clínica*.

Alumnos:
- Bengoa, Sebastian
- Echeverria, Noelia
- Ezama, Maria Camila
- Mateos, Juan Cruz

### Notas
* El *main* del programa esta en la clase App del paquete prueba.
* Documentacion: [Javadoc](https://htmlpreview.github.io/?https://github.com/JuanCruzMateos/Taller-I/blob/main/TP%20Final%20Clinica/javadoc/index.html)
