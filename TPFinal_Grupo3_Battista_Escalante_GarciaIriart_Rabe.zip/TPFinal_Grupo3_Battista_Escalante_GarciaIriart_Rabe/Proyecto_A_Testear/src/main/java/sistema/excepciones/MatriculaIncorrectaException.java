package sistema.excepciones;

public class MatriculaIncorrectaException extends Exception {
    public MatriculaIncorrectaException(String message) {
        super(message);
    }
}
