package sistema.excepciones;

public class SalaDeEsperaVaciaException extends Exception {
    public SalaDeEsperaVaciaException(String message) {
        super(message);
    }
}
